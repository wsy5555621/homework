
/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  wangshenyu                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Mengning, 2014/09/20
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include"menu.h"



/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}




/*add a menu into this program*/
int Addamenu(tLinkTable *ppLinktable)
{
    tDataNode *pNode;
    char cmd[10];
    char desc[100];
    printf("please input cmd name and press enter\n");
    scanf("%s",cmd);
    printf("please input cmd description and press enter\n");
    scanf("%s",desc);
    //printf("%s--%s\n",cmd,desc);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));

    pNode->cmd = (char *)malloc(sizeof (char)*10);
    pNode->desc = (char *)malloc(sizeof (char)*100);
    strcpy(pNode->desc,desc);
    strcpy(pNode->cmd,cmd);
    //pNode->cmd = cmd;
    //pNode->desc = desc;
    pNode->handler = NULL; 
    //printf("***%s--%s\n",pNode->cmd,pNode->desc);
    AddLinkTableNode(ppLinktable,(tLinkTableNode *)pNode);
    //printf("1***%s--%s***2\n",pNode->cmd,pNode->desc);
    return 0;
}

/*delete a menu from this program*/
int Deleteamenu(tLinkTable *ppLinktable,tDataNode *pNode)
{
    printf("delete which cmd?\n");
    char cmd[10];
    scanf("%s",cmd);
    pNode=FindCmd(ppLinktable,cmd);
    if((strcmp(cmd,"add")==0)||(strcmp(cmd,"delete")==0)||(strcmp(cmd,"help")==0)
||(strcmp(cmd,"version")==0)||(strcmp(cmd,"quit")==0))
    {
        printf("you can't delete the main cmd!\n");   
    }
    else if(pNode!=NULL)
    {
        DelLinkTableNode(ppLinktable,(tLinkTableNode *) pNode);
    }
    else printf("error!not found!\n");

}




