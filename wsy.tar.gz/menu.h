/**************************************************************************************************/
/* Copyright (C)  2014-2015                                                                       */
/*                                                                                                */
/*  FILE NAME             :  wsymenu.c                                                            */
/*  PRINCIPAL AUTHOR      :  Wangshenyu                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/11                                                           */
/*  DESCRIPTION           :  This is a menu program!                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wsy,2014/9/11.
 *
 */
 
#ifndef _MENU_H_
#define _MENU_H_

/*
 * A menu program for interface.
 */
void menu();


#endif /* _MENU_H_ */
