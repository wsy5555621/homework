This is a menu program!
Build Procedure
$ gcc linktable.c lintable.h menu.c menu.h test.c -o menu
$ ./menu # you can add a cmd first,and the you can input help cmd to see all cmds.
