This is a menu program!
Build Procedure
$ gcc linktable.c lintable.h menu.c menu.h test.c -o menu
$ ./menu # you can input help/version/quit cmd.
