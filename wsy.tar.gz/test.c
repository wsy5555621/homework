/**************************************************************************************************/
/* Copyright (C)  2014-2015                                                                       */
/*                                                                                                */
/*  FILE NAME             :  wsymenu.c                                                            */
/*  PRINCIPAL AUTHOR      :  Wangshenyu                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program!                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WSY, 2014/09/21
 *
 */

#include<stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include"menu.h"

int InitMenuData(tLinkTable ** ppLinktable);
int Help();
int Quit();

tLinkTable * head = NULL;



main()
{
    InitMenuData(&head);
    printf("test progrom is going!\n**********************\n");
    menu(head);
}

/* Here you can set some data for testing menu.c interface*/
int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
    tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "help";
    pNode->desc = "Menu List:";
    pNode->handler = Help;
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Quit; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "pgup";
    pNode->desc = "this is no.4 test cmd";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "pgdown";
    pNode->desc = "this is no.5 test cmd";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    
    return 0; 
}

int Help()
{
    ShowAllCmd(head);
    return 0; 
}

int Quit()
{
    exit(0);
}






