/**************************************************************************************************/
/* Copyright (C)  2014-2015                                                                       */
/*                                                                                                */
/*  FILE NAME             :  wsymenu.c                                                            */
/*  PRINCIPAL AUTHOR      :  Wangshenyu                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program!                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WSY, 2014/09/21
 *
 */

#include<stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include"menu.h"

int InitMenuData(tLinkTable ** ppLinktable);
void menu();
int Help();
int Quit();

tLinkTable * head = NULL;



main()
{
    InitMenuData(&head);
    printf("test progrom is going!\n**********************\n");
    Addamenu(head);
    menu();
}

/* Here you can set some data for testing menu.c interface*/
int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
    tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "help";
    pNode->desc = "Menu List:";
    pNode->handler = Help;
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Quit; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "add";
    pNode->desc = "follow the steps you can add a cmd!";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "delete";
    pNode->desc = "follow the steps you can delete a cmd!";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    
    return 0; 
}

int Help()
{
    ShowAllCmd(head);
    return 0; 
}

int Quit()
{
    exit(0);
}


/*run a menu using test's datas*/
void menu()
{ 
   /* cmd line begins */
    while(1)
    {
        char cmd1[CMD_MAX_LEN];
        printf("Input a cmd number > ");
        scanf("%s", cmd1);
        tDataNode *p = FindCmd(head, cmd1);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
            continue;
        }
	else if(strcmp(p->cmd,"add")==0)
        {
            Addamenu(head);continue;
        }
        else if(strcmp(p->cmd,"delete")==0)
        {
            Deleteamenu(head,p);continue;
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler();
        }
    }
}




