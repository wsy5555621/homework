/**************************************************************************************************/
/* Copyright (C)  2014-2015                                                                       */
/*                                                                                                */
/*  FILE NAME             :  wsymenu.c                                                            */
/*  PRINCIPAL AUTHOR      :  Wangshenyu                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/11                                                           */
/*  DESCRIPTION           :  This is a menu program!                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WSY, 2014/08/31
 *
 */

#include<stdio.h>
#include"menu.h"

main()
{
    printf("test progrom is going!\n");
    menu();
}
