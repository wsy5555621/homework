use "gcc linktable.h linktable.c menu.h menu.c test.c -o test.o" to get 
the executable file test.o, then use "./test.o" to test the driver.
 
